Param($instancename="Default",$MSAOU="OU=Service Accounts,OU=Administrative,DC=lan,DC=seanmassey,DC=net",$version="2012")

Function Create-MSA
{
	Param($MSAName,$MSADescription,$Servername,$DC,$Path)
	
	New-ADServiceAccount -Name $MSAName -Description $MSADescription -RestricttoSingleComputer -Server $DC -Path $Path
	Add-ADComputerServiceAccount -Identity $servername -ServiceAccount $MSAName -Server $DC

	Start-Sleep -seconds 10
	#Install-ADServiceAccount $MSAName
}

Import-Module ActiveDirectory

#Create Default Managed Service Account and Per-Server SQL Service Accounts if not present - Required for other MSAs to function properly
$DC = ($env:LogonServer).substring(2)
$servername = $env:ComputerName
$MSA = "svc"+$servername
$MSADefault = $MSA + "Default"
$MSAAG = $MSA+"AG"
$DefaultSA = Get-ADServiceAccount -Filter { CN -eq $MSADefault} -server $DC
If($DefaultSA -eq $null)
{
Create-MSA -MSAName $MSADefault -MSADescription "Service Account for the default Managed Service Account on $Servername. This account is required otherwise Managed Service Accounts on $Servername will not function" -Servername $servername -DC $DC -Path $MSAOU
Install-ADServiceAccount $MSADefault
}

$AGSA = Get-ADServiceAccount -Filter { CN -eq $MSAAG} -server $DC
If($AGSA -eq $null)
{
Create-MSA -MSAName $MSAAG -MSADescription "Service Account for SQL Server Agent on $Servername." -Servername $Servername -DC $DC -Path $MSAOU
Install-ADServiceAccount $MSAAG
}


#Configure MSAs for Instance-Specific Services
$TempInstanceName = $InstanceName
If($TempInstanceName -eq "Default")
{
$TempInstanceName = "MSSQLServer"
}

$length = $TempInstanceName.length
If($length -gt 5)
{
$MSA = $MSA+$TempInstanceName.substring(0,5)
}
Else
{
$MSA = $MSA+$TempInstanceName
}

$MSADB = $MSA+"DB"
$MSARS = $MSA+"RS"

$DBSA = Get-ADServiceAccount -Filter { CN -eq $MSADB} -server $DC
If($DBSA -eq $null)
{
Create-MSA -MSAName $MSADB -MSADescription "Service Account for $InstanceName Instance DB Engine on $Servername" -Servername $Servername -DC $DC -Path $MSAOU
Install-ADServiceAccount $MSADB
}


$RSSA = Get-ADServiceAccount -Filter { CN -eq $MSARS} -server $DC
If($DBSA -eq $null)
{
Create-MSA -MSAName $MSARS -MSADescription "Service Account for $InstanceName Instance Reporting Services on $Servername" -Servername $Servername -DC $DC -Path $MSAOU
Install-ADServiceAccount $MSARS
}


$MSADB = $MSADB + "`$"
$MSARS = $MSARS + "`$"
$MSAAG = $MSAAG + "`$"

$Path = "E:\SQLInstall\$version"


If($InstanceName -eq "Default")
{
$Datapath = "R:\$InstanceName"
$LogPath = "T:\$InstanceName"
$BackupPath = "S:\$InstanceName"
$InstanceName = "MSSQLServer"

.$path\Setup.exe /ACTION="Install" /UpdateSource="E:\SQLInstall\2012\CurrentUpdates" /IAcceptSQLServerLicenseTerms /Q /FEATURES=SQL,RS,TOOLS /INSTALLSHAREDDIR="E:\Program Files\Microsoft SQL Server" /INSTANCEDIR="E:\Program Files\Microsoft SQL Server" /INSTALLSQLDATADIR="E:\Program Files\Microsoft SQL Server" /INSTALLSHAREDWOWDIR="E:\Program Files (x86)\Microsoft SQL Server" /INSTANCENAME="$Instancename" /InstanceID="$InstanceName" /SQMREPORTING=0 /RSINSTALLMODE=FilesOnlyMode /ERRORREPORTING=0 /AGTSVCACCOUNT="LAN\$MSAAG" /AGTSVCSTARTUPTYPE="Automatic" /SQLSVCSTARTUPTYPE="Automatic" /SQLCOLLATION="SQL_Latin1_General_CP1_CI_AS" /SQLSVCACCOUNT="LAN\$MSADB" /SQLSYSADMINACCOUNTS="LAN\SQL Server Admins" /SQLBACKUPDIR="$BackupPath" /SQLUSERDBDIR="$DataPath" /SQLUSERDBLOGDIR="$LogPath" /SQLTEMPDBDIR="R:\TempDB\$InstanceName" /SQLTEMPDBLOGDIR="T:\TempDB\$InstanceName" /TCPENABLED="1" /RSSVCACCOUNT="LAN\$MSARS" 
}
Else
{
$Datapath = "R:\$InstanceName"
$LogPath = "T:\$InstanceName"
$BackupPath = "S:\$InstanceName"

.$path\Setup.exe /ACTION="Install" /UpdateSource="E:\SQLInstall\2012\CurrentUpdates" /IAcceptSQLServerLicenseTerms /Q /FEATURES=SQL,RS,TOOLS /INSTALLSHAREDDIR="E:\Program Files\Microsoft SQL Server" /INSTANCEDIR="E:\Program Files\Microsoft SQL Server" /INSTALLSQLDATADIR="E:\Program Files\Microsoft SQL Server" /INSTALLSHAREDWOWDIR="E:\Program Files (x86)\Microsoft SQL Server" /INSTANCENAME="$Instancename" /InstanceID="$InstanceName" /SQMREPORTING=0 /RSINSTALLMODE=FilesOnlyMode /ERRORREPORTING=0 /AGTSVCACCOUNT="LAN\$MSAAG" /AGTSVCSTARTUPTYPE="Automatic" /SQLSVCSTARTUPTYPE="Automatic" /SQLCOLLATION="SQL_Latin1_General_CP1_CI_AS" /SQLSVCACCOUNT="LAN\$MSADB" /SQLSYSADMINACCOUNTS="LAN\SQL Server Admins" /SQLBACKUPDIR="$BackupPath" /SQLUSERDBDIR="$DataPath" /SQLUSERDBLOGDIR="$LogPath" /SQLTEMPDBDIR="R:\TempDB\$InstanceName" /SQLTEMPDBLOGDIR="T:\TempDB\$InstanceName" /TCPENABLED="1" /RSSVCACCOUNT="LAN\$MSARS" 
}