﻿Param($Servername,$location,$IPAddress,[switch]$Dev,$CPUCount=1,$RAMCount=4,$Description)

add-pssnapin vmware.vimautomation.core
Import-Module ActiveDirectory,SQLPS

#Configure AD Credentials
$ADUser = "Automation Account"
$PWHash = Get-Content C:\Scripts\Other\$ADUser.txt
$key = $key = Get-Content C:\Scripts\Other\$ADUser.key
$securestring = ConvertTo-SecureString -String $PWHash -Key $key
$ADCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $ADUser,$securestring

#Configure vCenter Connection
$vCenterUser = "vCenter Account"
$PWHash = Get-Content C:\Scripts\Other\$vCenterUser.txt
$key = $key = Get-Content C:\Scripts\Other\$vCenterUser.key
$securestring = ConvertTo-SecureString -String $PWHash -Key $key
$vCenterCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $vCenterUser,$securestring

#Connect to vCenter
Connect-VIServer vCenter -Credential $vCenterCred

#Create Active Directory Computer Account in Proper OU
If($Dev -ne $true)
{
	New-ADComputer -Name $Servername -Path "ProdOU" -Server DC -Credential $ADCred
}
Else
{
	New-ADComputer -Name $Servername -Path "DevOU" -Server DC -Credential $ADCred
}

#Create Non-Persistent CustomizationSpec
$OSSpecName = "$Servername-NPSpec"

Get-OSCustomizationSpec -Name AutomationSpec | New-OSCustomizationSpec -Name $OSSpecName -Type NonPersistent

#Retrieve Location details for Spec
$LocationDetails = Invoke-Sqlcmd -query "Select * FROM OSCustomizationSettings WHERE Location_ID = '$Location'" -database OSCustomizationDB -serverinstance FTDC1-SQL3

$SubnetMask = $LocationDetails.Location_NetMask
$DefaultGW = $LocationDetails.Location_GW
$DataStore = $LocationDetails.Location_Datastore
$ESXiHost = $LocationDetails.Location_Host
$DNS = $LocationDetails.Location_DNS
$DNS = $DNS.Split(",")

#Set NIC Mapping on Spec
Get-OSCustomizationSpec -Name $OSSpecName | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping -IpMode UseStaticIP -IpAddress $IPAddress -SubnetMask $SubnetMask -DefaultGateway $DefaultGW -Dns $DNS

#Create VM, adjust resources, and Power on
New-VM -Name $Servername -Template "Windows Server 2012 R2 - JIT Template" -ResourcePool $ESXiHost -Datastore $Datastore -Notes $Description -OSCustomizationSpec $OSSpecName

Set-VM -VM $Servername -NumCpu $CPUCount -MemoryGB $RAMCount -Confirm:$false

Start-VM $Servername