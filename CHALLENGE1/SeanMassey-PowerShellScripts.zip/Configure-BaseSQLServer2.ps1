﻿Param($InstanceName="TempDB",$DataDriveLetter = "R",$LogDriveLetter = "T",$VolumeSize = "10",$Servername = "SQL01")

Function Create-VMDK
{
	#Create VMDK File on Server and Return VMDK File Name
	Param ($Servername,$VolumeSize,[switch]$Controller)
	
	If($Controller)
	{
		Shutdown-VMGuest -VM $Servername
		Do{
		$PowerState = (Get-VM -Name $Servername).PowerState
		}
		While($PowerState -ne "PoweredOff")
		
		$disk = New-HardDisk -VM $servername -Persistence persistent -CapacityGB $VolumeSize -StorageFormat Thin -Confirm:$false | New-ScsiController -Type Paravirtual
		
		Start-VM -VM $Servername | Wait-Tools		
	}
	Else
	{
		$disk = New-HardDisk -VM $servername -Persistence persistent -CapacityGB $VolumeSize -StorageFormat Thin -Confirm:$false
	}
	
	$Filename = $disk.filename
	$pos = $Filename.IndexOf("/")
	$Filename = $Filename.Substring($pos+1)
	
	#$pos = $Filename.IndexOf(".")
	#$Filename = $Filename.Substring(0,$pos)
	
	Return $Filename
}

Function Create-MountPoint
{
	#Initialize volume, create partition, mount as NTFS Mount Point, and format as NTFS Volume
	Param($Servername,$VolumeName,$VolumeSize,$Path,$CimSession)
	$VolumeSizeGB = [string]$VolumeSize + "GB"
	
	$partition = Get-Disk -CIMSession $CimSession | Where-Object {($_.partitionstyle -eq "raw") -and ($_.size -eq $VolumeSizeGB)} | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -UseMaximumSize

	$disknumber = $partition.DiskNumber
	$partitionnumber = $partition.partitionnumber

	Add-PartitionAccessPath -CimSession $CimSession -DiskNumber $disknumber -PartitionNumber $partitionnumber -AccessPath $Path -PassThru | Format-Volume -AllocationUnitSize 64KB -FileSystem NTFS -NewFileSystemLabel $VolumeName -Confirm:$false
}

Function Create-Drive
{
	#Initialize volume, create partition, mount to drive letter, and format as NTFS Volume
	Param($Servername,$VolumeName,$VolumeSize,$Path,$DriveLetter,$CimSession)
	$VolumeSizeGB = [string]$VolumeSize + "GB"
	$DriveAccessLetter = $DriveLetter + ":"
	
	$partition = Get-Disk -CIMSession $CimSession | Where-Object {($_.partitionstyle -eq "raw") -and ($_.size -eq $VolumeSizeGB)} | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -UseMaximumSize 
	
	$disknumber = $partition.DiskNumber
	$partitionnumber = $partition.partitionnumber

	Add-PartitionAccessPath -CimSession $CimSession -DiskNumber $disknumber -PartitionNumber $partitionnumber -AccessPath $DriveAccessLetter #-PassThru |Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $VolumeName -Confirm:$false
	Format-Volume -CIMSession $CimSession -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $VolumeName -Confirm:$false
}


add-pssnapin vmware.vimautomation.core
Import-Module ActiveDirectory

#Configure vCenter Connection
$vCenterUser = "vCenter Account"
$PWHash = Get-Content C:\Scripts\Other\$vCenterUser.txt
$key = $key = Get-Content C:\Scripts\Other\$vCenterUser.key
$securestring = ConvertTo-SecureString -String $PWHash -Key $key
$vCenterCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $vCenterUser,$securestring

#Configure Remote Server Connection
$ServerUser = "Account with Server Admin Priviledges"
$PWHash = Get-Content C:\Scripts\Other\$ServerUser.txt
$key = $key = Get-Content C:\Scripts\Other\$ServerUser.key
$securestring = ConvertTo-SecureString -String $PWHash -Key $key
$ServerCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $Serveruser,$securestring

Connect-VIServer vCenter -Credential $vCenterCred

$CimSession = New-CimSession -ComputerName $Servername -Credential $ServerCred

#Create E Drive
$Filename = Create-VMDK -Servername $Servername -Volumesize 50
$VolumeName = "Data-$Filename"
Create-Drive -Servername $Servername -VolumeName $VolumeName -VolumeSize 50 -DriveLetter "E" -CIMSession $CimSession


New-Item -Path "\\$servername\E`$" -Name SQLInstall -Type Directory

Invoke-Command -ComputerName $ServerName -ScriptBlock {Copy-Item -Path "Path to Application or File" -Destination "E:\SQLInstall" -Recurse} -Credential $ServerCred

#Create R Drive
$Filename = Create-VMDK -Servername $Servername -Volumesize 3
$VolumeName = "SQL Data-$Filename"
Create-Drive -Servername $Servername -VolumeName $VolumeName -VolumeSize 3 -DriveLetter "R" -CIMSession $CimSession

#Create S Drive
$Filename = Create-VMDK -Servername $Servername -Volumesize 200
$VolumeName = "SQL Backup-$Filename"
Create-Drive -Servername $Servername -VolumeName $VolumeName -VolumeSize 200 -DriveLetter "S" -CIMSession $CimSession
New-Item -ItemType Directory -Path "\\$Servername\S`$\SQL_Backups"

#Create T Drive
$Filename = Create-VMDK -Servername $Servername -Volumesize 3
$VolumeName = "SQL Logs-$Filename"
Create-Drive -Servername $Servername -VolumeName $VolumeName -VolumeSize 3 -DriveLetter "T" -CIMSession $CimSession

#Create TempDB Data Drive
$Filename = Create-VMDK -Servername $Servername -Volumesize $VolumeSize -Controller
$Path = "$DataDriveLetter`:\$Instancename"
New-Item -ItemType Directory -Path "\\$Servername\$DataDriveLetter`$\$InstanceName"
$VolumeName = "Data-$InstanceName-$Filename"
Create-Mountpoint -Servername $Servername -VolumeName $VolumeName -VolumeSize $VolumeSize -Path $Path -CIMSession $CimSession

#Create TempDB Log Volume
$Filename = Create-VMDK -Servername $Servername -Volumesize $VolumeSize -Controller
$Path = "$LogDriveLetter`:\$Instancename"
New-Item -ItemType Directory -Path "\\$Servername\$LogDriveLetter`$\$InstanceName"
$VolumeName = "Logs-$InstanceName-$Filename"
Create-Mountpoint -Servername $Servername -VolumeName $VolumeName -VolumeSize $VolumeSize -Path $Path -CIMSession $CimSession

